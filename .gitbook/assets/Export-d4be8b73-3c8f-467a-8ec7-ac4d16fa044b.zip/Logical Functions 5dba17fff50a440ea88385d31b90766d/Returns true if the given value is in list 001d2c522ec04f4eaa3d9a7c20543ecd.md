# Returns true if the given value is in list

Example: IF(IN(Region, ["West","East]),25, 30)
Explanation: Will return 25 if the region is West or East otherwise returns 30
NAME: IN
SYNTAX: https://www.notion.so/6fc18d83ebfb495291ca63568cf288db