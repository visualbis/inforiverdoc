# Returns a logical 'Exclusive Or' of all arguments

Example: IF(XOR(Region == "West", Category=="Urban"), 25, 30)
Explanation: Will return 25 for all category in the West except for category Urban, and returns 25 for all Urban category under all region except for west, for all other items returns 30
NAME: XOR
SYNTAX: https://www.notion.so/a7315f82ece246349d1c82a6ec7b75ba