# Checks whether any of the arguments are TRUE, and returns TRUE or FALSE. Returns FALSE only if all arguments are FALSE

Example: IF(OR(Region == "West", Region =="East"), 25, 30)
Explanation: Will return 25 if the region is West or East otherwise returns 30
NAME: OR
SYNTAX: https://www.notion.so/4c1b7f685af0441e9604833935aaeef6