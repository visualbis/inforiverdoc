# Return value2 if value1 is not number else returns value1

Example: IFNA((AC-PY)/PY, 0)
Explanation: Returns AC-PY/PY if the value is a number else returns 0
NAME: IFNA
SYNTAX: https://www.notion.so/d1a7985365884ba0b805d843fdb52249