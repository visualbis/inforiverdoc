# Checks whether a condition is met, and returns one value if TRUE, and another value if FALSE

Example: IF(PY > 0 , (AC-PY)/PY, 0 )
Explanation: Above formula will return AC-PY% if PY is greater than 0 otherwise it returns 0
NAME: IF
SYNTAX: https://www.notion.so/6597b14b08dd42b3a4cd56e49dab9f00