# Checks whether all the arguments are TRUE, and returns TRUE if all arguments are TRUE

Example: IF(AND(Region == "West", Category=="Urban"), 25, 30)
Explanation: Will return 25 if the region is West and category is Urban otherwise returns 30
NAME: AND
SYNTAX: https://www.notion.so/3f40472cb36d4d4eb63294594d963df8