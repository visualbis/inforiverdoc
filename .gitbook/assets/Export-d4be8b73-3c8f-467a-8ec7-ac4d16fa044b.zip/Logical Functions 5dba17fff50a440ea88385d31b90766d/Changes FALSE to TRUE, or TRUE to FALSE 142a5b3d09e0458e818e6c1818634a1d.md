# Changes FALSE to TRUE, or TRUE to FALSE

Example: IF(NOT(Region == "West"), 50, 25)
Explanation: Will return 50 if the region is not West otherwise returns 25
NAME: NOT
SYNTAX: https://www.notion.so/2a17eced958849bd8cc0cc486af4d255