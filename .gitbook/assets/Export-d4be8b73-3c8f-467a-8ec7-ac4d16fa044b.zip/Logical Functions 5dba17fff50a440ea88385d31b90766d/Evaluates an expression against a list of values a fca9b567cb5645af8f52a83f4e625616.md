# Evaluates an expression against a list of values and returns the result corresponding to the first matching value. If there is no match, an optional default value is returned.

Example: SWITCH(Region, "West", 25, "East",30, 50)
Explanation: Will return 25 if the region is West and 30 is region is East and 50 for all other regions
NAME: SWITCH
SYNTAX: https://www.notion.so/a676bd326102429f97b252010f249890